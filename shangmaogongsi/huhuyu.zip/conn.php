<?php 
$DB= new mysqli('localhost' , 'root' , '' , 'huhuyu' );//主机 用户 密码 数据库
$DB->set_charset( "utf8" );// 设置编码方式

?>